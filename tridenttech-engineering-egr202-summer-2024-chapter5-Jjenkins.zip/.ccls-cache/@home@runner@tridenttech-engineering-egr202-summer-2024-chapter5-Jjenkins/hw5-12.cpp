//hw5-12.cpp - displays the total owed
//Created/revised by <JeJuan Jenkins> on <July 18, 2024>

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

//declare variables 
	double price1 = 0.0; 
	double price2 = 0.0;
	double lowerSales = 0.0; 
	double higherSales = 0.0;

	cout << "Enter the price for the first item";
	cin >> price1; 
	cout << "Enter the price for the second item";
	cin >> price2;

	if (price1 > price2)
	{
		higherSales = price1;
		lowerSales = price2 * .5;
	}
	else
	{
		higherSales = price2;
		lowerSales = price1 * .5; 
	}
	cout << "The Total is $" << lowerSales + higherSales << endl;

	return 0;
} //end of main function 